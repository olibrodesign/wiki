import Router from './router';
// Global Stylesheet
import './style.scss';

// Main App component
const App = () => <Router />;

export default App;
